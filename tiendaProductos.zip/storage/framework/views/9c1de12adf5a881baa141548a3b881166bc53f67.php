<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Foto de Producto</div>

                    <div class="card-body">
                        <form enctype="multipart/form-data" method="post"
                              action="<?php echo e(!isset($objProducto)?route("producto.post-foto",$objProducto->id):""); ?>">
                            <?php echo csrf_field(); ?>
                            <div>
                                <label for="foto">Seleccione una imagen</label>
                                <input class="form-control" type="file" name="foto" id="foto"/>
                                <?php $__errorArgs = ["foto"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger">
                                    <span><?php echo e($message); ?></span>
                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mt-3">
                                <button class="btn btn-primary" type="submit">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Universidad\6 Semestre\Web2\practico2\proyect\resources\views/producto/foto.blade.php ENDPATH**/ ?>