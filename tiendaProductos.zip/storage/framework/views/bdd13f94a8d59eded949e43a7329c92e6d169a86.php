<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>
        <img class="foto-perfil" src="/images/<?php echo e($objProducto->getFotoPerfilForDisplay()); ?>" alt="foto"/>
    </div>
    <div>
        <h1><?php echo e($objProducto->nombre); ?></h1>
        <h1>Precio <?php echo e($objProducto->precio); ?></h1>
        <h2>Stock <?php echo e($objProducto->stock); ?></h2>
        <p><?php echo e($objProducto->descripcion); ?></p>
    </div>
    <?php if($objProducto->stock > 0): ?>
        <?php if(auth()->guard()->check()): ?>
<div>
    <form method="post" action="<?php echo e(route("venta.insert")); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" value="<?php echo e($objProducto->id); ?>" name="producto_id">
        <input type="hidden" value="<?php echo e(auth()->user()->id ?? ""); ?>" name="user_id">
        <select name="cantidad" id="cantidad" class="form-select">
            <?php for($num = 1; $num <=$objProducto->stock ; $num++): ?>
                <option value="<?php echo e($num); ?>">
                    <?php echo e($num); ?>

                </option>
            <?php endfor; ?>
        </select>

    <div class="mt-3">
        <button class="btn btn-primary" type="submit">Comprar</button>
    </div>
    </form>
</div>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Universidad\6 Semestre\Web2\practico2\proyect\resources\views/producto/detail.blade.php ENDPATH**/ ?>