<?php $__env->startSection('content'); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1 class="card-title mb-3">Productos de <?php echo e($listCategoriaProducto[0]->getNombreCategoriaForDisplay($listCategoriaProducto[0]->categoria_id)); ?></h1>
<?php $__currentLoopData = $listCategoriaProducto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoriaProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <a class="btn btn-success"
       href="<?php echo e(url("/producto/nav",$categoriaProducto->producto_id)); ?>">
        <img class="foto-perfil" src="/images/<?php echo e($categoriaProducto->getProductoForDisplay($categoriaProducto->producto_id)->getFotoPerfilForDisplay()); ?>" alt="foto"/>
        <br>
        <?php echo e($categoriaProducto->getProductoForDisplay($categoriaProducto->producto_id)->nombre); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Universidad\6 Semestre\Web2\practico2\proyect\resources\views/categoriaProductos/index.blade.php ENDPATH**/ ?>