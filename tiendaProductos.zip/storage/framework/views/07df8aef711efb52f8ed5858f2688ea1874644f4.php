<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Lista de Categorias-Productos</div>

                    <div class="card-body">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Categoria</th>
                                <th>Producto</th>
                                <th></th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $listCategoriaProducto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objCategoriaProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($objCategoriaProducto->id); ?></td>
                                    <td><?php echo e($objCategoriaProducto->getNombreCategoriaForDisplay($objCategoriaProducto->categoria_id)); ?></td>
                                    <td><?php echo e($objCategoriaProducto->getProductoForDisplay($objCategoriaProducto->producto_id)->nombre); ?></td>
                                    <td>
                                        <a class="btn btn-primary" href="<?php echo e(route("categorias_producto.edit",$objCategoriaProducto->id)); ?>">Editar</a>
                                    </td>
                                    <td>
                                        <form onsubmit="return confirm('Estás seguro que deseas eliminar?')"
                                              method="post" action="<?php echo e(route("categorias_producto.destroy",$objCategoriaProducto->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger" type="submit">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Universidad\6 Semestre\Web2\practico2\proyect\resources\views/categoriaProductos/list.blade.php ENDPATH**/ ?>