<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col">Lista de Productos</div>
                        </div>
                    </div>

                    <div class="card-body">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>Imagen</th>
                                <th>Id</th>
                                <th>Nombre</th>
                                <th>Stock</th>
                                <th>Precio</th>
                                <th>Descripcion</th>
                                <th></th>
                                <th></th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $listaProducto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><img class="foto-perfil" src="/images/<?php echo e($objProducto->getFotoPerfilForDisplay()); ?>" alt="foto"/></td>
                                    <td><?php echo e($objProducto->id); ?></td>
                                    <td><?php echo e($objProducto->nombre); ?></td>
                                    <td><?php echo e($objProducto->stock); ?></td>
                                    <td><?php echo e($objProducto->precio); ?></td>
                                    <td><?php echo e($objProducto->descripcion); ?></td>
                                    <td>
                                        <a class="btn btn-success"
                                           href="<?php echo e(route("producto.foto",$objProducto->id)); ?>">Foto de Perfil</a>
                                    </td>
                                    <td>
                                        <a class="btn btn-primary" href="<?php echo e(route("producto.edit",$objProducto->id)); ?>">Editar</a>
                                    </td>
                                    <td>
                                        <form onsubmit="return confirm('Estás seguro que deseas eliminar?')"
                                              method="post" action="<?php echo e(route("producto.destroy",$objProducto->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger" type="submit">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Universidad\6 Semestre\Web2\practico2\proyect\resources\views/producto/list.blade.php ENDPATH**/ ?>